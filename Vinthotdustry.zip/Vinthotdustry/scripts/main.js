
const createIconsC = (packer, block) => {
    for(var i = 0; i < block.variants; i++){
        var image = new Pixmap(32, 32);
        var shadow = Core.atlas.getPixmap(block.name + (i + 1));


        var offset = image.getWidth() / Vars.tilesize - 1;
        var color = new Color();


        for(var x = 0; x < image.getWidth(); x++){
            for(var y = offset; y < image.getHeight(); y++){
                shadow.getPixel(x, y - offset, color);

                if(color.a > 0.001){
                    color.set(0, 0, 0, 0.3);
                    image.draw(x, y, color);
                };
            };
        };
       
        image.draw(shadow);

        packer.add(MultiPacker.PageType.environment, block.name + (i + 1), image);
        packer.add(MultiPacker.PageType.editor, "editor-" + block.name + (i + 1), image);

        if(i == 0){
            packer.add(MultiPacker.PageType.editor, "editor-block-" + block.name + "-full", image);
            packer.add(MultiPacker.PageType.main, "block-" + block.name + "-full", image);
        };
    }
};



const obamiumOre = extendContent(OreBlock, "obamium", {
    init(){
        this.itemDrop = Vars.content.getByName(ContentType.item, "obamium
        ");
        this.super$init();
    },
    createIcons(packer){
        createIconsC(packer, this);
    }
});

obamiumOre.oreScale = 25.105874;
obamiumOre.oreThreshold = 0.873;
obamiumOre.oreDefault = true;

obamiumOre.cost = 2;
obamiumOre.hardness = 2;